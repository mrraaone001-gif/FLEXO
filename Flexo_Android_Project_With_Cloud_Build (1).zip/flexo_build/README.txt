FLEXO MAIL & CHAT — Android Studio project
Package: com.flexo.workspace
Version: 0.1.0

BUILD APK:
1. Install Android Studio (latest stable) and Android SDK Platform 35.
2. Open this folder in Android Studio.
3. Allow Gradle sync and install the Android Gradle Plugin if prompted.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be at app/build/outputs/apk/debug/app-debug.apk.

CURRENT PREVIEW FEATURES:
- Inbox with sample messages
- Compose/save demo email locally (not delivered)
- Demo chat threads and local message history
- Contacts and settings screens
- Android WebView wrapper

IMPORTANT LIMITATIONS:
This is a functional UI prototype, not a production email or messaging service.
No real email server, SMTP/IMAP, user registration, cloud database, push notifications,
multi-device sync, encryption/key management, or backend chat service is connected.
Do not use it for confidential or business-critical communication.
The app name "Flexo" is a working name; check trademarks and domain availability before commercial launch.

BUILD WITHOUT INSTALLING ANDROID STUDIO (GitHub Actions)
1. Create a new GitHub repository and upload all files/folders from this project,
   including the hidden .github folder.
2. Open the repository's Actions tab and select "Build FLEXO APK".
3. Click "Run workflow" (or wait for the first push build to finish).
4. Open the completed workflow run and download the "FLEXO-debug-apk" artifact.
5. Extract the downloaded artifact ZIP; it contains app-debug.apk.
6. Transfer app-debug.apk to your Android phone and tap it to install.

This creates a debug APK for testing. It is not a Play Store release build.
