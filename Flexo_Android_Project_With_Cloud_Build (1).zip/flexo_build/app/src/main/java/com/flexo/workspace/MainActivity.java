package com.flexo.workspace;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(21,94,239));
        getWindow().setNavigationBarColor(Color.rgb(16,42,86));
        WebView web = new WebView(this);
        web.setBackgroundColor(Color.rgb(243,246,252));
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        web.setWebViewClient(new WebViewClient());
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    @Override public void onBackPressed() {
        WebView w = (WebView)((android.view.ViewGroup)findViewById(android.R.id.content)).getChildAt(0);
        if (w != null && w.canGoBack()) w.goBack(); else super.onBackPressed();
    }
}
